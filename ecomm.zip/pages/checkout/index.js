import Checkout from '@components/Checkout'

const index = () => {
  return (
    <Checkout />
  )
}

export default index;