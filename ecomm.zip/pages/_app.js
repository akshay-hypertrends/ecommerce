import React, { createRef, useEffect } from "react";
import Layout from "@components/Layouts";
import "../styles/globals.css";
import CartContext from "@services/CartContext";
import { SnackbarProvider } from "notistack";
import { SnackbarUtilsConfigurator } from "@components/Notification";
import { IconButton } from "@mui/material";
import { Close } from "@mui/icons-material";
import "animate.css";

function MyApp({ Component, pageProps }) {
  const notistackRef = createRef();
  const onClickDismiss = (key) => () => {
    notistackRef.current.closeSnackbar(key);
  };

  return (
    <CartContext>
      <SnackbarProvider
        maxSnack={3}
        anchorOrigin={{
          vertical: "bottom",
          horizontal: "left",
        }}
        preventDuplicate
        autoHideDuration={5000}
        ref={notistackRef}
        action={(key) => (
          <IconButton style={{ color: "white" }} onClick={onClickDismiss(key)}>
            <Close />
          </IconButton>
        )}
      >
        <Layout>
          <Component {...pageProps} />
        </Layout>
        <SnackbarUtilsConfigurator />
      </SnackbarProvider>
    </CartContext>
  );
}

export default MyApp;
