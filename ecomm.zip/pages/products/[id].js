import Details from "@components/Products/Details";

const PrdocutDetails = () => {
  return (
    <Details />
  )
}

export default PrdocutDetails