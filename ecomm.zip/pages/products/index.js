import Products from "@components/Products/ProductPage";

const index = () => {
  return (<Products />);
};

export default index;
