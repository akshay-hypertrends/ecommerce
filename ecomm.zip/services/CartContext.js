import { snackActions } from "@components/Notification";
import React, {
  useState,
  createContext,
  useContext,
  useMemo,
  useEffect,
} from "react";

export const Cart = createContext({});

const CartContext = (props) => {

  const { children } = props;
  const [products, setProduct] = useState([]);
  const [subTotal, setSubTotal] = useState(0.00);
  const [totalAmount, setTotal] = useState(0.00);
  const [totalTax, setTax] = useState(0.00);
  const [totalShipping, setShipping] = useState(0.00);
  
  const updateCart = (product) => {
    setProduct((products) => products.filter((item) => item.id !== product.id));
    setProduct(oldArray => [...oldArray, product]);
  }
  
  const addToCart = (product,color=null,size=null) => {
    
    const data = {
      id : product.id,
      name : product.name,
      image: product.thumbnail,
      imageAlt: product.imageAlt,
      price: product.price.replace('$',''),
      qty: 1,
      shipping: product.shipping,
      tax: product.tax,
      color: color ? color : product.color[0],
      size: size ? size : product.size[2],
    }
    
    const found = products.find(element => element.id === product.id);
    if(found)
    {
      if(color || size)
      {
        data.qty = found.qty;
        updateCart(data);
      }
      else
      {
        snackActions.error("Item already in cart !");
        return ;
      }
    }
    else
    {
      setProduct(oldArray => [...oldArray, data]);
    }
  }

  const clearCart = () => {
    setProduct([]);
  }

  useEffect(() => {
    var taxs = 0;
    var shippings = 0;
    var total = 0;
    products.map((product) => {
      taxs = taxs + parseFloat(product.tax);
      shippings = shippings + parseFloat(product.shipping);
      total = total + (parseFloat(product.price) * parseInt(product.qty));
    });
    setTax(taxs);
    setShipping(shippings);
    setSubTotal(total);
    setTotal(taxs + shippings + total);
  },[products, setProduct]);

  const deleteCartItem = (product) => {
    setProduct((products) => products.filter((item, i) => item.id !== product.id));
  }
  
  const contextValues = useMemo(
    () => ({
      updateCart,
      addToCart,
      deleteCartItem,
      clearCart,
      products,
      subTotal,
      totalAmount,
      totalTax,
      totalShipping,
    }),
    [products, subTotal, totalAmount, totalTax, totalShipping]
  );

  return (
    <Cart.Provider value={contextValues}>
      {children}
    </Cart.Provider>
  );
};

export default CartContext;

export const useCart = () => useContext(Cart);
